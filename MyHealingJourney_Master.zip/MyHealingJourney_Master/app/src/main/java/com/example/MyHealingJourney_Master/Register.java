package com.example.MyHealingJourney_Master;

import android.app.ProgressDialog;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;



public class Register extends AppCompatActivity {
    RadioGroup radioGroup;
    RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        radioGroup = (RadioGroup)findViewById(R.id.RadioGroup);
    }


    public void onClick (View v) {
        int radiobutton = radioGroup.getCheckedRadioButtonId();
        radioButton = (RadioButton) findViewById(radiobutton);
    }
}
