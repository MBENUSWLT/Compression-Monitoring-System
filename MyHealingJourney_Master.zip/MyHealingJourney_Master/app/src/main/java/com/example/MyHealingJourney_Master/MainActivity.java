package com.example.MyHealingJourney_Master;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.MyHealingJourney_Master.Register;

public class MainActivity extends AppCompatActivity {
Button Login;
Button Register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Register = findViewById(R.id.btnRegister);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, com.example.MyHealingJourney_Master.Register.class);
                MainActivity.this.startActivity(intent);
            }
        });
    }
}
